Creates a node definition view of a project
User selects the start node by selecting an object in the hierarchy
Works in ADEP Designer 10, xml file is needed to work in this version