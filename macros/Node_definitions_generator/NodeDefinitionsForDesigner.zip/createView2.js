    // JavaScript Document
//values from the Flash Dialog
var indFieldIndex;
var indDelegate;
var indLabelKey;
var startIndex;
var delimiter=","; //delimiter variable for getting string from Flash dialog

 //indicators from teh flash dialog match the dialoog
 var stringIndexInd="fldindex";
 var stringDelegateInd="delegate";
 var stringLabelInd="label";
 var typeDelimiter=":";
 
function resetIndicators(){

    indFieldIndex=false;
    indDelegate=false;
    indLabelKey=false;
    startIndex=-1;
}


/**
*  setIndicators- gets the in memory variables from the dialog, and sets the macro equivalent variables
*@param toDecode- the string of settings set in the dialog
*@param fldStart- the index to start incrementing from for FieldIndex of the nodeDefinitions
*@param delimiter- the delimiter to split the toDecode string with
*@returns- null
**/
function setIndicators(toDecode,fldStart,delimiter){

    var indicatorStrings=toDecode.split(delimiter);
   if(fldStart){
        startIndex=parseInt(fldStart);
   }
    for(var i=0;i<indicatorStrings.length;i++){
          var indicatorPair=indicatorStrings[i].split(typeDelimiter);
          if(indicatorPair && indicatorPair.length==2){
            var pairVal=convertStringValue(indicatorPair[1]);
            switch(indicatorPair[0]){
            
                case stringIndexInd:
                    indFieldIndex=pairVal;     
                break;
                
                case stringDelegateInd:
                    indDelegate=pairVal;
                break;
                              
                case stringLabelInd:
                    indLabelKey=pairVal;
                    
                break;
            }
          }  
    }
}//end function


/**
* convertStringValue- if a string is 'true' returns a true boolean. case insensitive
* @param stringVal- the string to evaluate
* @returns- boolean, true if the string is "true"
*
**/
function convertStringValue(stringVal){

    if(stringVal===null) return false;
    if(stringVal.toLowerCase()==="true") return true;
    return false;

}
/**
* findViewScript looks for all scripts of a certain Name
* Currently this function is not being used
*
**/
function findViewScript(oNode, name) { 

    if (oNode.className === "script" && oNode.name===name) {
        return oNode;
    } 

    for (var i = 0; i < oNode.nodes.length; i++) {
         findViewScript(oNode.nodes.item(i));
    }
} 

/**
* getNodes- parses the tree of nodes from the current and constructs Node Definition string
* @param oNode- the starting source node
* @param vfunctions- the string array of node definitions. One per node definition
* @param parentName- the name of the oNode paretn
* @returns- null
*
**/
function getNodes(oNode,vFunctions,parentName){
    for (var i=0;i<oNode.nodes.length;i++){
         var oChildNode = oNode.nodes.item(i);
        
         var functionName="get"+parentName+"_"+oChildNode.name;
         designer.println(oChildNode.className+"\n");
        if( oChildNode.className==="field"|| oChildNode.className==="subform" || oChildNode.className==="draw"|| oChildNode.className==="exclGroup" ||  
                oChildNode.className==="pageSet"){  
            
           var  nodePropertyJS;
           var  nodeDefAlias=oChildNode.name;
           var  nodeDefSom=oChildNode.name;
           var nodeDefParentKey=parentName;
           var nodeDefLabelKey="label"+oChildNode.name;
           var nodeDefDelegate="";
           
            //create the node alias definition
            nodePropertyJS=nodeDefAlias+": {\n"+"\tsomExpression: \""+nodeDefSom+"\",\n" +"\tparentNodeKey: \""+nodeDefParentKey+"\"";
            
             //create the FieldIndex Key   
             if(indFieldIndex===true){   
                nodePropertyJS+= ",\n" + "\tfieldNumber: \""+(startIndex++)+"\"" 
             }
             
             //create the label key
            if(indLabelKey===true){
                nodePropertyJS+= ",\n" + "\tlabelKey: \""+ nodeDefLabelKey+"\"";     
            }
            if(indDelegate===true){
                 nodePropertyJS+=",\n"+ "\tdelegate: \""+ nodeDefLabelKey+"\""; 
            
            }
             nodePropertyJS+="},\n\n"
            vFunctions.push(nodePropertyJS);
        }//endfor
        
        //get children if a subform or an exclusion group
        if(oChildNode.className=="subform" ){
           
            getNodes(oChildNode,vFunctions,oChildNode.name)
        }else if(oChildNode.className==="exclGroup"){
            //the parent is the parent subform
             getNodes(oChildNode,vFunctions,parentName)
        }
        
    }
}

/**
* createParentJS- creates the starting (first) node handles all the root node stuff
* @param oNode- the starting source node
* @param vfunctions- the string array of node definitions. One per node definition
* @param nodeAlias- the name of the oNode paretn
* @returns- the alias assigned to this node
*
**/
function  createParentJS(oNode,vFunctions){
    
           var  nodeDefAlias=oNode.name;
           var  nodeDefSom=oNode.name;
           var nodeDefParentKey=oNode.parent.name;
           var nodeDefLabelKey="label"+oNode.name;
           var nodeDefDelegate="delegate"+oNode.name;
            
            if(testForRoot(oNode)){
                nodeDefAlias="root";
                nodeDefSom="xfa.form."+oNode.name;
                nodeDefParentKey=null;
                nodeDefLabelKey=null;
                nodeDefDelegate=null;
                nodeDefFldNumber=0;
            }
            
            var  nodePropertyJS=nodeDefAlias+": {\n"+"\tsomExpression: \""+nodeDefSom+"\",\n"
             if(nodeDefParentKey!==null) nodePropertyJS+="\tparentNodeKey: \""+nodeDefParentKey+"\"";
                
             if(indFieldIndex===true){   
                 nodePropertyJS+=",\n"+ "\tfieldNumber: \""+(startIndex++)+"\"" 
             }
             
             if(nodeDefLabelKey!==null && indLabelKey===true){
              nodePropertyJS+=",\n"+ "\tlabelKey: \""+ nodeDefLabelKey+"\"";   
             }
            
            if(indDelegate===true &&  nodeDefDelegate!==null){
                 nodePropertyJS+=",\n"+ "\tdelegate: \""+  nodeDefDelegate+"\""; 
            
            }           
            nodePropertyJS+="},\n\n"
            vFunctions.push(nodePropertyJS);
            return (nodeDefAlias);
}


/**
* testForRoot- determines is a given node is the root node
*@param oNode- the node to test
*@returns- boolean, true if a root node
**/
function testForRoot(oNode){

    if(oNode.parent.name==="template" || oNode.parent.name==="form"){
        return true;
    }
    return false;
}


/**
* initializeMacro - opens the flex dialog, gets the dialog indicator and kicks off the node parse
*
*@returns- null
**/
function initializeMacro(){

    resetIndicators();
    // Get the list of selected nodes
    var selection = designer.getSelection();
    
    if( selection.length==0) selection=xfa.template;
    
    var viewFunctions=[];
    var theScript="start\n"; //indicator that something was processed, could be removed
    
    //designer.alert(selection.item(0).name+" "+selection.item(0).className +selection.length);
    
    var notCancelled=designer.showFlexDialog("CreateViewForDesigner.swf", 275, 175);
    if(notCancelled==="ok"){
        var result= designer.getDialogString("outputChoices"); 
        var startfld=designer.getDialogString("fldIndexStart"); 
        setIndicators(result,startfld,delimiter);

    }else if(notCancelled==="cancel"){
     return;
    }
    
    if(selection.length==1 && selection.item(0).className==="subform" ){
        var parentName=createParentJS(selection.item(0),viewFunctions);
        getNodes(selection.item(0),viewFunctions,parentName);
        //getNodes(selection.item(0),viewFunctions,"");
        
        for(var t=0;t<viewFunctions.length;t++){
            theScript+=viewFunctions[t];
        }
    }
     designer.showTextWindow(theScript);

}



/**
* Equivalent of main. Macro calls this code
*
*
**/
initializeMacro();



